def add():
    a=int(input("Enter the value: "))
    b=int(input("Enter the value: "))
    res=a+b  
    print(res)
if __name__=='__main__':
     add()