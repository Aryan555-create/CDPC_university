#Question: Rotate an array to the right by a given number of steps
#sample input: [1,2,3,4,5] rotated by 2 steps 
#expected out: [4,5,1,2,3]
def rotate_right(arr, k):
    n = len(arr)
    k = k % n
    return arr[-k:] + arr[:-k]

arr = [1,2,3,4,5]
k = 2

result = rotate_right(arr, k)
print(result)

code6] Shifiting array by n steps
n = int(input("Enter the number of Elements: "))
arr = []
for i in range(n):
    a = int(input("Enter the number: "))
    arr.append(a)
b = int(input("Enter the number of steps: "))
for _ in range(b):
    last_element = arr[n-1]
    for i in range(n-1, 0, -1):
        arr[i] = arr[i-1]
    arr[0] = last_element
for i in range(n):
    print(arr[i])