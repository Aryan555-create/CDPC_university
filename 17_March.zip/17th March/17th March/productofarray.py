#Find the majority element:
#Question : Find the majority element (element that appears motre than n/2 times)  in an array.
#sample input : [3,3,4,2,4,4,2,4,4]
#Expected output : Majority Element : 4  
arr = [3,3,4,2,4,4,2,4,4]

n = len(arr)

for i in arr:
    if arr.count(i) > n // 2:
        print("Majority Element :", i)
        break

code5] Product of array except self
arr = [1, 2, 3, 4]
n = len(arr)

result = [1] * n

# Left pass
left = 1
for i in range(n):
    result[i] = left
    left *= arr[i]

# Right pass
right = 1
for i in range(n-1, -1, -1):
    result[i] *= right
    right *= arr[i]

print(result)
