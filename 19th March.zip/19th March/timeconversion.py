def timeConversion(s):
    period = s[-2:]
    hr, minutes, seconds = s[:-2].split(":")

    if period == "AM":
        if hr == "12":
            hr = "00"
    else:
        if hr != "12":
            hr = str(int(hr) + 12)

    return f"{hr}:{minutes}:{seconds}"
if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = timeConversion(s)

    fptr.write(result + '\n')

    fptr.close()
