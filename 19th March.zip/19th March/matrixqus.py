# create a maxtrix such that row wise and coloum wise both the answer should be 15 
# 8  1  6
# 3  5  7
# 4  9  2
matrix = [
    [8, 1, 6],
    [3, 5, 7],
    [4, 9, 2]
]

for row in matrix:
    print(*row)
