def miniMaxSum(arr):
   def miniMaxSum(arr):
    res=[]
    s=0
    for i in range(len(arr)):
        s=sum(arr)-arr[i]
        res.append(s)
    print(min(res),max(res))


if __name__ == '__main__':

    arr = list(map(int, input().rstrip().split()))

    miniMaxSum(arr)
