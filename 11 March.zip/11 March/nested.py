
# =====================================================
# Program: Number Patterns using Nested Loops
# Author: Aryan
# =====================================================

print("Pattern 1: Square of repeated row numbers")
for i in range(1,5):
    for j in range(1,5):
        print(i, end="")
    print()
print("")

print("Pattern 2: Square of increasing numbers")
for i in range(1,5):
    for j in range(1,5):
        print(j, end="")
    print()
print("")

print("Pattern 3: Increasing numbers per row (triangle)")
for i in range(1,5):
    for j in range(1,i+1):
        print(j, end="")
    print()
print("")

print("Pattern 4: Decreasing numbers per row (triangle)")
for i in range(4,0,-1):
    for j in range(1,i+1):
        print(j, end="")
    print()
print("")

print("Pattern 5: Triangle of repeated numbers")
for i in range(1,5):
    for j in range(1,i+1):
        print(i, end="")
    print()
print("")