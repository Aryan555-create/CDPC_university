# =====================================================
# Program: Star Patterns and String Handling in Python
# Author: Aryan
# =====================================================

# 1️⃣ Increasing Star Pattern
print("Pattern 1: Increasing Stars")
rows = 4
for i in range(1, rows+1):
    print("*" * i)  # simpler way instead of inner loop
print("")  # blank line

# Output:
# *
# **
# ***
# ****

# 2️⃣ Decreasing Star Pattern
print("Pattern 2: Decreasing Stars")
for i in range(rows, 0, -1):
    print("*" * i)
print("")  

# Output:
# ****
# ***
# **
# *

# 3️⃣ Optional: Right-aligned Pyramid
print("Pattern 3: Right-aligned Pyramid")
for i in range(1, rows+1):
    print(" " * (rows-i) + "*" * i)
print("")

# Output:
#    *
#   **
#  ***
# ****

# =====================================================
# 4️⃣ String Handling Examples
print("String Handling Examples\n")

text = "Hello Python Programming"

# Length of string
print("Length of string:", len(text))

# Accessing characters
print("First character:", text[0])
print("Last character:", text[-1])

# Slicing
print("Substring [0:5]:", text[0:5])
print("Substring [6:12]:", text[6:12])

# Convert to uppercase / lowercase
print("Uppercase:", text.upper())
print("Lowercase:", text.lower())

# Check if string starts/ends with something
print("Starts with 'Hello':", text.startswith("Hello"))
print("Ends with 'Programming':", text.endswith("Programming"))

# Find position of substring
print("Position of 'Python':", text.find("Python"))

# Replace substring
print("Replace 'Python' with 'Java':", text.replace("Python", "Java"))

# Split string
words = text.split()
print("Split into words:", words)

# Join list of strings
joined = "-".join(words)
print("Joined with '-':", joined)

# Check membership
print("'Python' in text:", "Python" in text)
print("'Java' in text:", "Java" in text)

# =====================================================
print("\nProgram Completed")